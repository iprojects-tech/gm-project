import VideoAnalyzer from "@/components/video-analyzer"

export default function AnalyzerPage() {
  return <VideoAnalyzer />
}
